if (typeof kotlin === 'undefined') {
  throw new Error("Error loading module 'main'. Its dependency 'kotlin' was not found. Please, check whether 'kotlin' is loaded prior to 'main'.");
}var main = function (_, Kotlin) {
  'use strict';
  var throwCCE = Kotlin.throwCCE;
  var equals = Kotlin.equals;
  var toShort = Kotlin.toShort;
  var println = Kotlin.kotlin.io.println_s8jyv4$;
  var toString = Kotlin.toString;
  var answer1;
  var answer2;
  var answer3;
  var answer4;
  var answer5;
  var questoes;
  var q1;
  var q2;
  var q3;
  var q4;
  var q5;
  var newPage;
  var nome;
  var canvas;
  function pegarResp() {
    var resp1 = answer1.value;
    var resp2 = answer2.value;
    var resp3 = answer3.value;
    var resp4 = answer4.value;
    var resp5 = answer5.value;
    if (equals(resp1.toUpperCase(), 'BRASIL')) {
      q1.innerHTML = 'Voc\xEA acertou a quest\xE3o 1';
    }var tmp$ = equals(resp2.toUpperCase(), 'KLOSE');
    if (!tmp$) {
      tmp$ = equals(resp2.toUpperCase(), 'MIROSLAV KLOSE');
    }if (tmp$) {
      q2.innerHTML = 'Voc\xEA acertou a quest\xE3o 2';
    }var tmp$_0 = equals(resp3, '1930');
    if (!tmp$_0) {
      tmp$_0 = equals(resp3.toUpperCase(), 'MIL NOVECENTOS E TRINTA');
    }if (tmp$_0) {
      q3.innerHTML = 'Voc\xEA acertou a quest\xE3o 3';
    }if (equals(resp4.toUpperCase(), 'URUGUAI')) {
      q4.innerHTML = 'Voc\xEA acertou a quest\xE3o 4';
    }var tmp$_1 = equals(resp5.toUpperCase(), 'CATAR');
    if (!tmp$_1) {
      tmp$_1 = equals(resp5.toUpperCase(), 'QATAR');
    }if (tmp$_1) {
      q5.innerHTML = 'Voc\xEA acertou a quest\xE3o 5';
    }}
  function mouse_down(ev) {
    var tmp$, tmp$_0, tmp$_1;
    if (ev.buttons !== toShort(0)) {
      var canvas = Kotlin.isType(tmp$ = document.getElementById('canvas'), HTMLCanvasElement) ? tmp$ : throwCCE();
      var ctx = Kotlin.isType(tmp$_0 = canvas.getContext('2d'), CanvasRenderingContext2D) ? tmp$_0 : throwCCE();
      ctx.fillStyle = 'rgb(0,255,0)';
      ctx.fillRect(ev.offsetX, ev.offsetY, 10.0, 10.0);
    }println('mouse pressionado em (' + ev.offsetX + ',' + ev.offsetY + ') botoes ' + ev.buttons);
    var canvas_0 = Kotlin.isType(tmp$_1 = document.getElementById('canvas'), HTMLCanvasElement) ? tmp$_1 : throwCCE();
    canvas_0.focus();
  }
  function key_event(ev) {
    println('Tecla ' + ev.key);
  }
  function submitAnswers() {
    var tmp$;
    var botao = Kotlin.isType(tmp$ = document.getElementById('botaoResp'), HTMLButtonElement) ? tmp$ : throwCCE();
    botao.style.display = 'none';
    pegarResp();
    questoes.style.display = 'none';
    newPage.style.display = 'block';
    var pegarNome = window.prompt('Jogador, digite seu nome');
    nome.innerHTML = toString(pegarNome);
    nome.style.display = 'block';
    canvas.style.display = 'block';
  }
  function mostarResp() {
    var abrir = window.confirm('Apertando sim o navegador abrir\xE1 mais uma p\xE1gina');
    if (abrir) {
      window.open('https://projetoLPFQuiz.gnovaesf.repl.co/respostaHist.html');
    }}
  function main() {
    var tmp$, tmp$_0;
    var canvas = Kotlin.isType(tmp$ = document.getElementById('canvas'), HTMLCanvasElement) ? tmp$ : throwCCE();
    var ctx = Kotlin.isType(tmp$_0 = canvas.getContext('2d'), CanvasRenderingContext2D) ? tmp$_0 : throwCCE();
    ctx.fillStyle = 'rgb(0,255,0)';
    ctx.fillRect(10.0, 20.0, 50.0, 50.0);
    ctx.fillStyle = 'rgb(0,0,255)';
    ctx.arc(130.0, 100.0, 20.0, 0.0, 2 * 3.14);
    ctx.fill();
    ctx.strokeText('ola do canvas', 50.0, 120.0);
    ctx.stroke();
    println('exemplo de Canvas');
  }
  Object.defineProperty(_, 'answer1', {
    get: function () {
      return answer1;
    }
  });
  Object.defineProperty(_, 'answer2', {
    get: function () {
      return answer2;
    }
  });
  Object.defineProperty(_, 'answer3', {
    get: function () {
      return answer3;
    }
  });
  Object.defineProperty(_, 'answer4', {
    get: function () {
      return answer4;
    }
  });
  Object.defineProperty(_, 'answer5', {
    get: function () {
      return answer5;
    }
  });
  Object.defineProperty(_, 'questoes', {
    get: function () {
      return questoes;
    }
  });
  Object.defineProperty(_, 'q1', {
    get: function () {
      return q1;
    }
  });
  Object.defineProperty(_, 'q2', {
    get: function () {
      return q2;
    }
  });
  Object.defineProperty(_, 'q3', {
    get: function () {
      return q3;
    }
  });
  Object.defineProperty(_, 'q4', {
    get: function () {
      return q4;
    }
  });
  Object.defineProperty(_, 'q5', {
    get: function () {
      return q5;
    }
  });
  Object.defineProperty(_, 'newPage', {
    get: function () {
      return newPage;
    }
  });
  Object.defineProperty(_, 'nome', {
    get: function () {
      return nome;
    }
  });
  Object.defineProperty(_, 'canvas', {
    get: function () {
      return canvas;
    }
  });
  _.pegarResp = pegarResp;
  _.mouse_down = mouse_down;
  _.key_event = key_event;
  _.submitAnswers = submitAnswers;
  _.mostrarRespostas = mostarResp;
  _.main = main;
  var tmp$, tmp$_0, tmp$_1, tmp$_2, tmp$_3, tmp$_4, tmp$_5, tmp$_6, tmp$_7, tmp$_8, tmp$_9, tmp$_10, tmp$_11, tmp$_12;
  answer1 = Kotlin.isType(tmp$ = document.getElementById('question1'), HTMLInputElement) ? tmp$ : throwCCE();
  answer2 = Kotlin.isType(tmp$_0 = document.getElementById('question2'), HTMLInputElement) ? tmp$_0 : throwCCE();
  answer3 = Kotlin.isType(tmp$_1 = document.getElementById('question3'), HTMLInputElement) ? tmp$_1 : throwCCE();
  answer4 = Kotlin.isType(tmp$_2 = document.getElementById('question4'), HTMLInputElement) ? tmp$_2 : throwCCE();
  answer5 = Kotlin.isType(tmp$_3 = document.getElementById('question5'), HTMLInputElement) ? tmp$_3 : throwCCE();
  questoes = Kotlin.isType(tmp$_4 = document.getElementById('quizquestions'), HTMLDivElement) ? tmp$_4 : throwCCE();
  q1 = Kotlin.isType(tmp$_5 = document.getElementById('q1'), HTMLDivElement) ? tmp$_5 : throwCCE();
  q2 = Kotlin.isType(tmp$_6 = document.getElementById('q2'), HTMLDivElement) ? tmp$_6 : throwCCE();
  q3 = Kotlin.isType(tmp$_7 = document.getElementById('q3'), HTMLDivElement) ? tmp$_7 : throwCCE();
  q4 = Kotlin.isType(tmp$_8 = document.getElementById('q4'), HTMLDivElement) ? tmp$_8 : throwCCE();
  q5 = Kotlin.isType(tmp$_9 = document.getElementById('q5'), HTMLDivElement) ? tmp$_9 : throwCCE();
  newPage = Kotlin.isType(tmp$_10 = document.getElementById('mostrarRespostas'), HTMLButtonElement) ? tmp$_10 : throwCCE();
  nome = Kotlin.isType(tmp$_11 = document.getElementById('nome'), HTMLDivElement) ? tmp$_11 : throwCCE();
  canvas = Kotlin.isType(tmp$_12 = document.getElementById('canvas'), HTMLCanvasElement) ? tmp$_12 : throwCCE();
  main();
  Kotlin.defineModule('main', _);
  return _;
}(typeof main === 'undefined' ? {} : main, kotlin);
